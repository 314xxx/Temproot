#!/system/bin/sh
MODDIR=${0%/*}
sleep 6
sh "$MODDIR/action.sh"
