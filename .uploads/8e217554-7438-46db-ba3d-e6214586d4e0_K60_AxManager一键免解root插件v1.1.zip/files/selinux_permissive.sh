#!/system/bin/sh
MODDIR=${0%/*}
CF_SOURCE="$MODDIR/../files/cf"
CF_TARGET="/data/local/tmp/cf"

# 每次执行前：重新复制cf到tmp并赋777权限
cp -f "$CF_SOURCE" "$CF_TARGET"
chmod 777 "$CF_TARGET"
chown shell:shell "$CF_TARGET"

echo "开始SELinux宽容注入..."
COUNT=0

while true
do
    COUNT=$((COUNT + 1))
    echo "[TRY $COUNT] 执行注入..."
    export SELINUX_VIRTUAL=0xffffffc00aa42b90
    "$CF_TARGET"
    RESULT=$(getenforce | tr -d '\r')
    echo "[TRY $COUNT] 当前SELinux状态: $RESULT"

    if [ "$RESULT" = "Permissive" ]; then
        echo ""
        echo "=============================="
        echo "[SUCCESS] SELinux宽容成功"
        echo "总尝试次数: $COUNT"
        echo "=============================="
        break
    else
        echo "SELinux宽容未成功，继续重试..."
    fi
    sleep 1
done
echo "最终SELinux状态: $(getenforce | tr -d '\r')"
