#!/system/bin/sh
rm -f /data/local/tmp/cf
rm -f /sdcard/ksud
rm -f /sdcard/ksulog.txt
