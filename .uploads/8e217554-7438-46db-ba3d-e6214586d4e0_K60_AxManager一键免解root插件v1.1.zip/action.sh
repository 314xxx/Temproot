#!/system/bin/sh
MODDIR=${0%/*}
echo "===== 开始一键临时Root ====="
sh "$MODDIR/files/selinux_permissive.sh"
sleep 2
sh "$MODDIR/files/imqs_root.sh"
echo "===== 全部执行完成 ====="
