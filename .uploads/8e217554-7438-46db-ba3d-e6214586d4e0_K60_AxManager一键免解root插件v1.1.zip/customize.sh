#!/system/bin/sh
# 空脚本，不再提前复制文件，避免tmp目录清空失效
